console.log('Hey Harry')

console.info('info')
console.warn('warn')
console.error('err')
console.assert('err')
console.time('forlo')

for(let i=0; i < 5; i ++) {
  console.log(213)
}